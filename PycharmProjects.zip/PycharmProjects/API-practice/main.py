import requests

# Define the API endpoint URL
url = "https://ron-swanson-quotes.herokuapp.com/v2/quotes"

# Send a GET request to the API
response = requests.get(url)

# Check for successful response
if response.status_code == 200:
    # Parse the JSON response
    data = response.json()

    # Extract the quote
    quote = data[0]

    # Print the quote
    print(f"Ron Swanson says: {quote}")
else:
    print(f"Error: API request failed with status code: {response.status_code}")
