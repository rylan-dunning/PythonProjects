with open("my_file.txt") as file:
    contents = file.read()
    print(contents)

with open("../../../Desktop/hello.txt", mode="a") as file:
    file.write("I love smoothies.")
