from turtle import Turtle
import random
from scoreboard import ScoreBoard


class Food(Turtle):

    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.penup()
        self.shapesize(stretch_len=0.5, stretch_wid=0.5)
        self.color("red")
        self.speed("fastest")
        self.refresh()

    def refresh(self):
        rand_x = random.randint(-280, 280)
        rand_y = random.randint(-280, 280)
        self.goto(rand_x, rand_y)

    def eat_food(self, snake, scoreboard):
        # detect collision with food
        if snake.head.distance(self) < 15:
            self.refresh()
            snake.extend()

            scoreboard.get_point()
