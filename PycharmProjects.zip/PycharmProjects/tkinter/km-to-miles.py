from tkinter import *

FONT = ("Arial", 12, "bold")


def calculate():
    mi_num.config(text=f"{float(miles_input.get()) * 0.62}")


window = Tk()
window.title("Km to Mile Converter")
window.minsize(width=300, height=200)

miles_input = Entry()
miles_input.grid(column=1, row=0)

km_label = Label(text="Km", font=FONT)
km_label.grid(column=2, row=0)

is_equal_label = Label(text="is equal to", font=FONT)
is_equal_label.grid(column=0, row=1)

mi_num = Label(text="0", font=FONT)
mi_num.grid(column=1, row=1)

mi_label = Label(text="Miles", font=FONT)
mi_label.grid(column=2, row=1)

button = Button(text="Calculate", command=calculate)
button.grid(column = 1, row = 2)






window.mainloop()
