from tkinter import *


def button_clicked():
    my_label["text"] = input.get()
    print("Nooooo")


window = Tk()
window.title("My first GUI program")
window.minsize(width=500, height=300)

# label
my_label = Label(text="I am a Label", font=("Arial", 24, "bold"))
# update properties
my_label["text"] = "Don't touch the button"
my_label.config(text="Don't touch the button")
my_label.grid(column=0, row=0)
my_label.config(padx=10, pady=10)

# entry
input = Entry(width=10)
input.grid(column=4, row=3)

# button
button = Button(text="Click Me", command=button_clicked)
button.grid(column=1, row=1)

button_2 = Button(text="No, click me!")
button_2.grid(column=2, row=0)

# always at the end
window.mainloop()
"""
.pack() - packs it from a certain direction
.place() - specify x and y coords
.grid() - define a column and row - starts in the top left
warning - can't use grid and pack together!!!!!
"""