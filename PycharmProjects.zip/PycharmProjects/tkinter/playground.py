def add(*args):
    sum = 0
    for n in args:
        sum += n
    print(sum)


add(8,9,984,2,4256,2312,256,3467,453457,99999999999999)

def calculate(n, **kwargs):
    print(kwargs)
    n += kwargs["add"]
    n += kwargs["multiply"]
    print(n)


calculate(2, add=2, multiply=2)


def funky(num, *args, **kwargs):
    for n in args:
        n += kwargs["add"]
        n *= num

    print(sum(args)/kwargs["divide"])


funky(2, (1, 2, 3), add=30, divide=2)


