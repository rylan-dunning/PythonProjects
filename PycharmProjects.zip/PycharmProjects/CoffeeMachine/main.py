from data import resources, MENU

isTrue = True


def report():
    for i in resources:
        print(f"{i}: {resources[i]}")


def choice(drink, machine):
    for i in MENU[drink]['ingredients']:
        if (machine[i] - MENU[drink]['ingredients'][i]) <= 0:
            print(f"Sorry, there is not enough {i}.")
            break
        else:
            if payment(drink):
                for i in MENU[drink]['ingredients']:
                    machine[i] = machine[i] - MENU[drink]['ingredients'][i]
                print(f"Here is your {drink}. Enjoy!")
                return
            else:
                return


def payment(drink):
    print("Please enter coins:")
    quarters = int(input("Quarters: "))
    dimes = int(input("Dimes: "))
    nickels = int(input("Nickels: "))
    pennies = int(input("Pennies: "))

    total = (0.25*quarters)+(0.1*dimes)+(0.05*nickels)+(0.01*pennies)
    if MENU[drink]['cost'] - total > 0:
        print("Sorry, that is not enough money. Money refunded.")
        return False
    elif MENU[drink]['cost'] - total == 0:
        resources['money'] += total
        return True
    else:
        extra = total - (MENU[drink]['cost'])
        print(f"Here is {round(extra, 2)} in change.")
        resources['money'] += (total - extra)
        return True




while isTrue:
    userIn = input("What would you like? (espresso/latte/cappuccino): ")
    if userIn == "report":
        report()
    elif userIn == "off":
        break
    else:
        choice(userIn, resources)


