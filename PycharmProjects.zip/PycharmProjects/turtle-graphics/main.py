from turtle import Turtle as t, Screen, pos, colormode
import random

timmy = t()
timmy.shape("turtle")
timmy.color("chartreuse", "green")


# Timmy makes a pentagon
# for i in range(5):
#     timmy.forward(100)
#     timmy.left(72)

# Timmy makes a cool star
# while True:
#     timmy.forward(200)
#     timmy.left(170)
#     if abs(timmy.pos()) < 1:
#         break

# Timmy makes a dotted line
# for i in range(50):
#     timmy.forward(3)
#     timmy.up()
#     timmy.forward(3)
#     timmy.down()

# Timmy draws a bunch of shapes
# colormode(255)
# timmy.up()
# timmy.backward(75)
# timmy.left(90)
# timmy.forward(300)
# timmy.down()
# timmy.right(90)
# for i in range(3, 22):
#     rand_color = (random.randrange(255), random.randrange(255), random.randrange(255))
#     timmy.pencolor(rand_color)
#     for j in range(0, i):
#         timmy.forward(100)
#         timmy.right(360/i)

# Timmy creates a Random Walk

def change_color():
    colormode(255)
    rand_color = (random.randrange(255), random.randrange(255), random.randrange(255))
    return rand_color
#
#
# def random_walk(steps):
#     timmy.pensize(15)
#     timmy.speed("fastest")
#     directions = [0, 90, 180, 270]
#     for i in range(0, steps):
#         timmy.color(change_color())
#         timmy.left(random.choice(directions))
#         timmy.forward(30)
#
#
# random_walk(200)


# Timmy makes a spirograph

def circle_thing(num_circles):
    timmy.speed("fastest")
    for i in range(0, num_circles):
        timmy.color(change_color())
        timmy.circle(100)
        timmy.left(360/num_circles)


circle_thing(90)


screen = Screen()
screen.exitonclick()