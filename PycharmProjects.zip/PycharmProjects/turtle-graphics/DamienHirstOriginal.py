import colorgram
from turtle import Turtle as t, Screen, pos, colormode
import random

timmy = t()
timmy.shape("turtle")

colorgram_colors = colorgram.extract('dots.jpg', 10)
colors = []

for color_element in colorgram_colors:
    red = color_element.rgb.r
    green = color_element.rgb.g
    blue = color_element.rgb.b
    tup = (red, green, blue)
    colors.append(tup)


def turtle_painting():

    y = -250
    x = -275

    timmy.speed("fastest")
    timmy.up()
    timmy.sety(y)
    timmy.setx(x)
    colormode(255)
    for i in range(0, 10):
        timmy.sety(y)
        timmy.setx(x)

        for j in range(0, 10):
            timmy.dot(25, random.choice(colors))
            timmy.forward(60)

        y += 60


turtle_painting()
screen = Screen()
screen.exitonclick()