import turtle

class Score(turtle.Turtle):
    def __init__(self):
        super().__init__()
        self.hideturtle()
        self.penup()
        self.goto(0, 250)
        self.color("black")
        self.points = 0
        self.write(f"States Correct: {self.points}")

    def update_score(self):
        self.clear()
        self.points += 1
        self.write(f"States Correct: {self.points}")

    def game_over(self):
        pass