import turtle
import pandas
from score import Score
from state import WriteState

screen = turtle.Screen()

screen.title("U.S. States Game")
image = "blank_states_img.gif"
screen.addshape(image)
turtle.shape(image)


# def get_mouse_click_coor(x, y):
#     print(x, y)
#
# turtle.onscreenclick(get_mouse_click_coor)
# turtle.mainloop()

states_data = pandas.read_csv('50_states.csv')
all_states = states_data.state.to_list()

correct_states = []

score = Score()

while len(correct_states) < 50:
    answer_state = screen.textinput(title=f"{len(correct_states)}/50 States Correct", prompt="Enter a state name: ")
    answer_state = answer_state.title()
    if answer_state == "Exit":
        break
    for state in states_data.state:
        if answer_state == state:
            state_info = states_data[states_data['state'] == answer_state]
            x_coord = state_info['x'].item()
            y_coord = state_info['y'].item()
            new_state = WriteState(x_coord, y_coord, state)
            if state not in correct_states:
                correct_states.append(state)
                score.update_score()
            elif state in correct_states:
                pass

with open('states_to_learn.csv', mode='w') as file:
    missing_states = [state for state in all_states if state not in correct_states]
    new_data = pandas.DataFrame(missing_states)
    new_data.to_csv("states_to_learn.csv")