from turtle import Turtle

class WriteState(Turtle):
    def __init__(self, x, y, state):
        super().__init__()
        self.hideturtle()
        self.penup()
        self.color("black")
        self.goto(x, y)
        self.write(state)