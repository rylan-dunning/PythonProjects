from turtle import Turtle



class Paddle(Turtle):
    def __init__(self, x_coord, y_coord):
        super().__init__()
        self.speed("fastest")
        self.shape("square")
        self.color("white")
        self.shapesize(stretch_wid=5, stretch_len=1)
        self.penup()
        self.X = x_coord
        self.Y = y_coord
        self.goto(self.X, self.Y)

    def up(self):
        self.Y += 20
        self.goto(self.X, self.Y)

    def down(self):
        self.Y -= 20
        self.goto(self.X, self.Y)
