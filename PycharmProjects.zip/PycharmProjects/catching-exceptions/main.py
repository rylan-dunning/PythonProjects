try:
    file = open("a_file.txt")
except:
    file = open("a_file.txt", mode="w")
    file.write("something")