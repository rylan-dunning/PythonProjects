import smtplib
import datetime as dt
import random

with open('quotes.txt') as file:
    # quote_list = [line.split('\n') for line in file]
    quote_list = file.readlines()


now = dt.datetime.now()
day = now.weekday()

my_email = "b.rylan.dunning@gmail.com"
password = "dwjwnpkiwlinjwgh"

quote = random.choice(quote_list)

if day == 1:
    with smtplib.SMTP("smtp.gmail.com") as connection:# smtp.mail.yahoo.com
        connection.starttls()
        connection.login(user=my_email, password=password)
        connection.sendmail(
            from_addr=my_email,
            to_addrs="rylan.dunning@yahoo.com",
            msg=f"Subject:Hello!\n\n{quote}"
        )

