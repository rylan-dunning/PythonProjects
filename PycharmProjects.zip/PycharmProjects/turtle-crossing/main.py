import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)

player1 = Player()
car_mngr = CarManager()
scoreboard = Scoreboard()


screen.listen()
screen.onkey(player1.up, "Up")


game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()
    car_mngr.create_car()
    car_mngr.drive()

    for car in car_mngr.all_cars:
        if car.distance(player1) < 20:
            game_is_on = False
            scoreboard.game_over()

    if player1.ycor() >= 270:
        player1.starting_position()
        car_mngr.level_up()
        scoreboard.level_up()


screen.exitonclick()