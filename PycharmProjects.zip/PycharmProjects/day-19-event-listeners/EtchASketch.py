from turtle import Turtle, Screen, clearscreen

tim = Turtle()
tim.shape("turtle")

new_screen = Screen()
new_screen.listen()


def the_game():

    def move_forward():
        tim.forward(100)

    def move_backward():
        tim.backward(10)

    def turn_right():
        tim.right(10)

    def turn_left():
        tim.left(10)

    def clear_screen():
        tim.clear()
        tim.up()
        tim.home()
        tim.down()


    new_screen.onkey(key="Up", fun=move_forward)
    new_screen.onkey(key="Left", fun=turn_left)
    new_screen.onkey(key="Right", fun=turn_right)
    new_screen.onkey(key="Down", fun=move_backward)
    new_screen.onkey(key="c", fun=clear_screen)
    new_screen.exitonclick()



the_game()
