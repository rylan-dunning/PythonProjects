# with open("weather_data.csv", mode="r") as file:
#     data = file.readlines()


# import csv
# with open("weather_data.csv", mode="r") as file:
#     data = csv.reader(file)
#     temperatures = []
#     for row in data:
#         if row[1] != 'temp':
#             temperatures.append(int(row[1]))
#     print(temperatures)

# import pandas
#
# data = pandas.read_csv('weather_data.csv')
#
# print(sum(data['temp']) / len(data['temp']))
#
# print(data['temp'].mean())
#
# print(data[data.temp == data.temp.max()])
#
#
# monday = data[data.day == "Monday"]
#
# print(monday.temp[0] * (9/5)+32)
#
# #create a df from scratch
#
# df = pandas.DataFrame(data)
#
# print(df)

import pandas

data = pandas.read_csv('2018_Squirrel_Data.csv')

greys = len(data[data['Primary Fur Color'] == "Gray"])
reds = len(data[data['Primary Fur Color'] == "Cinnamon"])
blacks = len(data[data['Primary Fur Color'] == "Black"])

print(greys)
print(reds)
print(blacks)

data_dict = {
    "Fur Color": ["Gray", "Cinnamon", "Black"],
    "Count": [greys, reds, blacks]
}

df = pandas.DataFrame(data_dict)
df.to_csv("squirrel_count")